#pragma once

#define MESS_UPDATE_ADDCLIENT 1 //32(client_name)
#define MESS_UPDATE_REMOVECLIENT 2 //32(client_name)
#define MESS_UPDATE_KEEPALIVE 3
#define MESS_UPDATE_KEEPALIVE_REPLY 4
